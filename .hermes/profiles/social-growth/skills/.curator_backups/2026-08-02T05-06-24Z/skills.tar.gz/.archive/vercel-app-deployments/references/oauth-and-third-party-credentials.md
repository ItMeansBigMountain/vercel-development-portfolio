# OAuth / Third-Party Credential Handling for App Deployments

Use when a user provides app credentials during deployment triage.

## Secure handling pattern

1. Acknowledge receipt without repeating secret values.
2. Store real values only in ignored local `.env` files or provider environment variables.
3. Verify ignore rules before committing: `git check-ignore -v path/to/.env`.
4. Set local secret file permissions to owner-only where possible: `chmod 600 .env`.
5. Commit only redacted documentation/status docs that name missing keys, not values.
6. If secrets were posted in chat, recommend rotation before final production launch.

## Spotify redirect URL pattern

For Flask apps, inspect the actual OAuth route before telling the user what to configure. In the MusicAI legacy app, docs/code used:

```text
SPOTIFY_CALLBACK_URL=http://localhost:5000/login/
```

The Spotify Developer Dashboard redirect URI must match exactly, including scheme, port, path, and trailing slash. After production deployment, add the deployed equivalent too:

```text
https://<live-domain>/login/
```

## Genius credential distinction

Genius may provide OAuth client ID/secret, but many legacy lyrics integrations use a direct bearer token / Client Access Token instead. Check code for `GENIUS_API_KEY` versus `GENIUS_CLIENT_ID` / `GENIUS_CLIENT_SECRET` before assuming the provided values are sufficient.

## IBM Watson NLU retrieval

For Watson Natural Language Understanding, the deployment usually needs both a service credential API key and service URL. An `ibmcloud login -u passcode -p ...` passcode is only a CLI login secret; it is not the Watson NLU runtime API key and should not be wired into the app. One-time passcodes expire quickly; if the CLI returns `BXNIM0418E ... Provided passcode is invalid`, ask the user for a fresh passcode instead of trying to reuse it.

Common env names to support/check in legacy projects:

- `WATSON_APIKEY` or `WATSON_NLU_APIKEY`
- `WATSON_INSTANCE_URL` or `WATSON_NLU_URL`
- Some docs may say `WATSON_API_KEY` / `WATSON_SERVICE_URL`; normalize or support aliases.

User retrieval path: IBM Cloud resources → Natural Language Understanding instance → Manage or Service credentials → copy `apikey` and `url`.

CLI retrieval path when the user provides a fresh passcode:

```bash
set +x
export PATH=/opt/data/bin:$PATH
ibmcloud login -a https://cloud.ibm.com -u passcode -p "$IBM_CLOUD_PASSCODE"
ibmcloud target --cf || true
ibmcloud resource service-instances --service-name natural-language-understanding
# If an NLU instance exists:
ibmcloud resource service-keys --instance-name "<nlu-instance-name>"
ibmcloud resource service-key "<key-name>" --output JSON
# If no key exists, create one and then read it:
ibmcloud resource service-key-create "hermes-nlu-key" Manager --instance-name "<nlu-instance-name>"
ibmcloud resource service-key "hermes-nlu-key" --output JSON
```

Do not print the JSON credentials to chat. Extract only the presence of `apikey` and `url`, then set provider env vars or an ignored local `.env`.

When the user asks to "save it in your .env" after Watson credential retrieval, update both the workspace-level `.env` and the immediately affected project `.env` files. Support common aliases so legacy code can read the same secret without another pass:

```env
IBM_CLOUD_API_KEY=<runtime service api key>
IBM_NLU_API_KEY=<runtime service api key>
WATSON_NLU_APIKEY=<runtime service api key>
IBM_NLU_URL=<nlu instance url>
WATSON_NLU_URL=<nlu instance url>
```

Then `chmod 600` the `.env` files and verify by key presence/count only, never by printing values. If the stored credential JSON has `apikey` but not `url`, recover the URL from the known NLU instance metadata or prior verified service URL; do not invent it.

To verify a Watson NLU key without logging into the CLI, exchange the service API key for an IAM bearer token, then call the NLU analyze endpoint with a harmless sentiment request. Report only a status such as `NLU verification OK: en neutral`, not the token or API key.

If `ibmcloud` is missing and there is no `sudo`, install it locally by downloading the Linux tarball via IBM's install metadata and copying `Bluemix_CLI/bin/ibmcloud` to `/opt/data/bin/ibmcloud`; do not record this as a permanent environment limitation.

If the app must be demoed before Watson credentials are available, keep Watson optional and provide a transparent non-secret fallback analyzer rather than blocking deployment.

## Agora credential distinction

Agora App ID can be client-visible, but the primary certificate must stay server-side. For production, generate short-lived Agora tokens server-side rather than exposing the certificate in browser JavaScript.
